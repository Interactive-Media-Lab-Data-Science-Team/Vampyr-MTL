# Vampyr-MTL
---

**Vampyr-MTL** is a machine learning python package inspired by [MALSAR](https://github.com/jiayuzhou/MALSAR) multi-task learning Matlab algorithm, combined with up-to-date multi-task learning researches and algorithm for public research purposes.

## Functionality
* Algorithms:
  - Multitask Binary Logistic Regression
    + Hinge Loss 
    + L21 normalization
  - Multitask Linear Regression
    + Mean Square Error
    + L21 normalization
* Util Functions:
  - Train Test Data Split
    + Split data set inside each task with predefined proportions
  - Cross Validation with k Folds:
    + Cross validation with predefined k folds and scoring methods

## Related Reseaches
[Accelerated Gredient Method](https://arxiv.org/pdf/1310.3787.pdf)

[Clustered Multi-Task Learning: a Convex Formulation](https://papers.nips.cc/paper/3499-clustered-multi-task-learning-a-convex-formulation.pdf)

[Regularized Multi-task Learning](https://dl.acm.org/doi/pdf/10.1145/1014052.1014067)

## Installation
``pip install -i https://test.pypi.org/simple/ Vampyr-MTL-Max-JJ==0.0.1``

## Package Update

* Manual Deployment:

  - [test-pypi manual](https://packaging.python.org/tutorials/packaging-projects/)

  - ``python setup.py sdist bdist_wheel``

  - ``python3 -m twine upload --repository testpypi dist/*``

* Automation(Linux):
  - deploy: ``./build_deploy.sh``
  - test: ``./build_deploy.sh --test``

